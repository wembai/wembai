<?php
$servername = "localhost";
$username = "root";
$password = "";

// Conexión al servidor MySQL
$conn = new mysqli($servername, $username, $password);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Crear una nueva base de datos
$sql = "CREATE DATABASE mibasededatos";
if ($conn->query($sql) === TRUE) {
    echo "Base de datos creada correctamente";
} else {
    echo "Error al crear la base de datos: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>