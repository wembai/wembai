<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "mi_basededatos";

// Conexión al servidor MySQL
$conn = new mysqli($servername, $username, $password, $database);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Consulta SQL para crear una tabla llamada "usuarios"
$sql = "CREATE TABLE usuarios (
    usuario VARCHAR(30) NOT NULL,
    contraseña VARCHAR(50) NOT NULL
)";

// Ejecutar la consulta
if ($conn->query($sql) === TRUE) {
    echo "Tabla usuarios creada correctamente";
} else {
    echo "Error al crear la tabla: " . $conn->error;
}

// Cerrar la conexión
$conn->close();
?>